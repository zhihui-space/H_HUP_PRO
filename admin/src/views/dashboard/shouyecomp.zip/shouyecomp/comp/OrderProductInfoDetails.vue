<template>
  <el-dialog title="订单产品详情" :visible.sync="thisViewDialogVisiable" @close="closeDialog" width="1000px">
    <div style="margin-left: 10px; margin-bottom:20px">
      <el-tag>详情信息</el-tag>
      <hr />
    </div>

    <el-form :inline="true" :model="formInline" label-width="120px">
      <el-form-item label="签订日期：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="预计交货日期：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="交货日期：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="客户编码：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="合同编号：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="客户名称：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="产品编号：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="产品名称：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="订单数量：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="含率单价：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="税率：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="价税合计：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="订单利润：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="合同类型：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="销售员：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="订单状态：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

      <el-form-item label="订单备注：">
        <el-input v-model="formInline.user"></el-input>
      </el-form-item>

    </el-form>
  </el-dialog>
</template>

<script>
export default {
  name: 'OrderProductInfoDetails',
  props: ["visiable", "pkProductOrderB"],
  data() {
    return {
      thisViewDialogVisiable: false, // 合同订单详细数据显示控制
      formInline: {
        orderCreationtime: '', // 签订日期
        scheduledtime: '', // 预计交货日期
        交货日期: '', // 交货日期
        code: '', // 客户编码
        contractNo: '', // 合同编号
        客户名称: '', // 客户名称
        productCode: '', // 产品编号
        productName: '', // 产品名称
        productNum: '', // 订单数量
        含率单价: '', // 含率单价
        taxinclud: '', // 税率
        totalPrice: '', // 价税合计
        订单利润: '', // 订单利润
        orderType: '', // 合同类型
        psndocName: '', // 销售员
        billState: '', // 订单状态
        memo: '' // 订单备注
      },
    }
  },
  watch: {
    visiable() {
      this.thisViewDialogVisiable = this.visiable
      if (this.visiable === true) {
        this.initOrderBProductDataByPrimary()
      }
    }
  },
  methods: {
    closeDialog() { // 回调关闭Dialog
      this.$emit('close', null)
    },
    // 根据订单字表主键查询订单产品详情数据
    initOrderBProductDataByPrimary() {
      if (this.pkProductOrderB != null) {
        let initQueryParam = {
          pkProductOrderB: this.pkProductOrderB
        }
        // 调用查询接口 将结果赋值给 this.formInline
      }
    }
  }
}
</script>

<style>

</style>

